using Microsoft.AspNetCore.Mvc;

namespace FilmAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FilmListController : ControllerBase
    {
        private readonly ILogger<FilmListController> _logger;

        public FilmListController(ILogger<FilmListController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetFilmList")]
        public IEnumerable<Film> Get()
        {
            List<Film> films = Films.getFilms();
            films.Sort((f1, f2) => f2.ReleaseDate.CompareTo(f1.ReleaseDate));
            return films;
        }
    }
}