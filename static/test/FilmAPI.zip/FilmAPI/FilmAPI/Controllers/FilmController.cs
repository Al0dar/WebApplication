using Microsoft.AspNetCore.Mvc;

namespace FilmAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FilmController : ControllerBase
    {
        private readonly ILogger<FilmListController> _logger;

        public FilmController(ILogger<FilmListController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetFilm")]
        //public IEnumerable<Film> Get(long id)
        public Film Get(long id)
        {
            List<Film> list = Films.getFilms().Where(f => f.ID == id).ToList();
            Film film = null;
            try
            {
                film = list.FirstOrDefault();
            }
            catch { }
            return film;
        }
    }
}