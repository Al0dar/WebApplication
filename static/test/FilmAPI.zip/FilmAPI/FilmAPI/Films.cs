namespace FilmAPI
{
    public class Films
    {
        public static List<Film> getFilms()
        {
            List<Film> list = new List<Film>();
            list.Add(new Film
            {
                ID = 1,
                Name = "Pulp Fictionl",
                ReleaseDate = DateTime.Parse("14 oct 1994"),
                Director = "Quentin Tarantino"
            });
            list.Add(new Film
            {
                ID = 2,
                Name = "Independence Day",
                ReleaseDate = DateTime.Parse("3 july 1996"),
                Director = "Roland Emmerich"
            });
            list.Add(new Film
            {
                ID = 3,
                Name = "True Romance",
                ReleaseDate = DateTime.Parse("10 sep 1993"),
                Director = "Tony Scott"
            });
            list.Add(new Film
            {
                ID = 4,
                Name = "Goodfellas",
                ReleaseDate = DateTime.Parse("19 sep 1990"),
                Director = "Martin Scorsese"
            });
            return list;
        }
    }
}